# -*- coding: utf-8 -*-
from linepy import *
from datetime import datetime
from time import sleep
from bs4 import BeautifulSoup
from humanfriendly import format_timespan, format_size, format_number, format_length
import time, random, sys, json, codecs, threading, glob, re, string, os, requests, subprocess, six, ast, pytz, urllib, urllib.parse,timeit,data,atexit
from gtts import gTTS
from googletrans import Translator
botStart = time.time()
cl = LINE()
cl.log("Auth Token : " + str(cl.authToken))
channelToken = cl.getChannelResult()
cl.log("Channel Token : " + str(channelToken))
oepoll = OEPoll(cl)
readOpen = codecs.open("read.json","r","utf-8")
settingsOpen = codecs.open("temp.json","r","utf-8")
read = json.load(readOpen)
settings = json.load(settingsOpen)
myProfile = {
	"displayName": "",
	"statusMessage": "",
	"pictureStatus": ""
}
mid1 = 'u800b5f33bdfebcc0f2f878ff5c712180'
mid2 = 'u800b5f33bdfebcc0f2f878ff5c712180'
lineSettings = cl.getSettings()
clProfile = cl.getProfile()
clMID = cl.profile.mid
myProfile["displayName"] = clProfile.displayName
myProfile["statusMessage"] = clProfile.statusMessage
myProfile["pictureStatus"] = clProfile.pictureStatus
admin = ['u800b5f33bdfebcc0f2f878ff5c712180', clMID, mid1, mid2]
wait2 = {
    'readPoint':{},
    'readMember':{},
    'setTime':{},
    'ROM':{}
}
setTime = {}
setTime = wait2['setTime']
cctv={
    "cyduk":{},
    "point":{},
    "sidermem":{}
}
msg_dict = {}
bl = [""]
def cTime_to_datetime(unixtime):
    return datetime.datetime.fromtimestamp(int(str(unixtime)[:len(str(unixtime))-3]))
def restartBot():
    print ("[ INFO ] BOT RESETTED")
    backupData()
    python = sys.executable
    os.execl(python, python, *sys.argv)
    
def backupData():
    try:
        backup = settings
        f = codecs.open('temp.json','w','utf-8')
        json.dump(backup, f, sort_keys=True, indent=4, ensure_ascii=False)
        backup = read
        f = codecs.open('read.json','w','utf-8')
        json.dump(backup, f, sort_keys=True, indent=4, ensure_ascii=False)
        return True
    except Exception as error:
        logError(error)
        return False
def restart_program():
    python = sys.executable
    os.execl(python, python, * sys.argv)
def logError(text):
    cl.log("[ ERROR ] " + str(text))
    time_ = datetime.now()
    with open("errorLog.txt","a") as error:
        error.write("\n[%s] %s" % (str(time), text))
def sendMessageWithMention(to, mid):
    try:
        aa = '{"S":"0","E":"3","M":'+json.dumps(mid)+'}'
        text_ = '@x '
        cl.sendMessage(to, text_, contentMetadata={'MENTION':'{"MENTIONEES":['+aa+']}'}, contentType=0)
    except Exception as error:
        logError(error)
def helpmessage():
    helpMessage = """
        ||=======================||
         ✒️ 👑sᴇʟғʙᴏᴛ ᴛʜᴀɪʟᴀɴᴅ 👑✒️
        ||=======================||

            🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥

👑✒️👑 「คำสั่ง」
👑✒️👑 「ลูกเล่น」
👑✒️👑 「คำสั่งเตะ」
👑✒️👑 「คท」
👑✒️👑 「ไอดีเรา」
👑✒️👑 「ชื่อเรา」
👑✒️👑 「ตัสเรา」
👑✒️👑 「รูปเรา」
👑✒️👑 「รูป VDO」
👑✒️👑 「ปกเรา」
👑✒️👑 「คท @」
👑✒️👑 「ไอดี @」
👑✒️👑 「ชื่อ @」
👑✒️👑 「ตัส @」
👑✒️👑 「รูป @」
👑✒️👑 「Vdo @」
👑✒️👑 「ปก @」
👑✒️👑 「copy @」
👑✒️👑 「คืนร่าง」
👑✒️👑 「คนสร้างกลุ่ม」
👑✒️👑 「ไอดีกลุ่ม」
👑✒️👑 「ชื่อกล่ม」
👑✒️👑 「รูปกล่ม」
👑✒️👑 「ลิ้งห้อง」
👑✒️👑 「เปิด/ปิด/ลิ้ง」
👑✒️👑 「กลุ่มของเรา」
👑✒️👑 「เชคคนในกลุ่ม」
👑✒️👑 「เชคขอมูลกลุ่ม」
👑✒️👑 「ล้อเล่น @」
👑✒️👑 「ปลิว @」
👑✒️👑 「ส่งแขก @」
👑✒️👑 「ไปหำ @」
👑✒️👑 「Vk:mid」
👑✒️👑 「Nk Name」
👑✒️👑 「Uk mid」
👑✒️👑 「NT Name」
👑✒️👑 「มองไม่เห็น」
👑✒️👑 「แทคล่องหน」
👑✒️👑 「ไอดีล่องหน」
👑✒️👑 「ล่องหน」
👑✒️👑 「Cancel」
👑✒️👑 「Gcancel」
👑✒️👑 「Gn Name」
👑✒️👑 「Gc @」
👑✒️👑 「Inv mid」
👑✒️👑 「ดำ @」
👑✒️👑 「Unban @」
👑✒️👑 「พวกดื้อ」
👑✒️👑 「ล้างหนังหมา」
👑✒️👑 「ไปเส้」
👑✒️👑 「แทค」
👑✒️👑 「Sn」
👑✒️👑 「R」」
👑✒️👑 「เทส1」
👑✒️👑 「เทสส2」
👑✒️👑 「Mimic On/Off」
👑✒️👑 「MimicList」
👑✒️👑 「MimicAdd @」
👑✒️👑 「MimicDel @」

---🏆🌟Self & Kicker Premium🌟🏆---
─┅═हই ᵀᴱᴬᴹᴃᴏᴛ ᴌᵻᴎᴇ™ᵀᴴᴬᴵᴸᴬᴺᴰ ইह═┅─

🔥🔥🔥 คำสั่งตั้งค่า  🔥🔥🔥

👑✒️👑 「เปิดแอด/ปิดแอด」
👑✒️👑 「เปิดเข้า/ปิดเข้า」
👑✒️👑 「เข้าแชท/ออกแชท」
👑✒️👑 「เปิดอ่าน/ปิดอ่าน」
👑✒️👑 「เปิดติก/ปิดติก」
👑✒️👑 「เปิดแทค/ปิดแทค」
👑✒️👑 「เปิดคท/ปิดคท」
👑✒️👑 「เปิดติก/ปิดติก」
👑✒️👑 「เปิดเชิญ/ปิดเชิญ」
👑✒️👑 「เปิดมุดลิ้ง/ปิดมุดลิ้ง」
👑✒️👑 「เปิดป้องลิ้ง/ปิดป้องกันลิ้ง」
👑✒️👑 「เปิดป้องกัน/ปิดป้องกัน

╔•═•-⊰✯⊱•═•⊰✯⊱•═•⊰✯⊱ •═•╗ 
✫   👑ŤỂÄΜ ж βǾŦ👑฿Ǿ¥👑    ✫   
╚•═•-⊰✯⊱•═•⊰✯⊱•═•⊰✯⊱ •═•╝


        •   S҉̉̈́͐͋҉̉̈́͐͋K҉̉̈́͐͋҉̉̈́͐͋Y҉ͩ͂҉̉̈́͐͋҉̉̈́͐͋⚒B҉̉̈́͐͋Ω҉̉̈́͐͋T҉̉̈́͐͋S҉̉̈́͐͋   •

 
ŤỂÄΜ Bot :👑ŤỂÄΜ ж βǾŦ👑฿Ǿ¥👑 

"""
    return helpMessage
def helpmessagetag():
    helpMessageTag ="""
╔══[ ลูกเล่นของเชล ]════════
👑✒️ 「ล้อเล่น @」
👑✒️ 「ปลิว @」
👑✒️ 「ส่งแขก @」
👑✒️ 「ไปหำ @」
👑✒️ 「Gc @」
👑✒️ 「ไอดี @」
👑✒️ 「ชื่อ @」
👑✒️ 「ตัส @」
👑✒️ 「รูป @」
👑✒️ 「ปก @」
👑✒️ 「Copy @」
👑✒️ 「MimicAdd @」
👑✒️ 「MimicDel @」
👑✒️ 「ดำ @」
👑✒️ 「Unban @」
╚═〘  👑ŤỂÄΜ ж βǾŦ👑฿Ǿ¥👑 〙
"""
    return helpMessageTag
def helpmessagekick():
    helpMessageKick ="""
╔══[ คำสั่งเตะ ]════════
👑✒️ 「ล้อเล่น @」
👑✒️ 「ปลิว @」
👑✒️ 「ส่งแขก @」
👑✒️ 「ไปหำ @」
👑✒️ 「Vk:mid」
👑✒️ 「Nk Name」
👑✒️ 「Uk mid」
👑✒️ 「ไปเส้」
👑✒️ 「มองไม่เห็น」
╚═〘 👑ŤỂÄΜ ж βǾŦ👑฿Ǿ¥👑  〙
"""
    return helpMessageKick
def helpmessagebot():
    helpMessageBot ="""
╔══〘 Help Message 〙✪═══════
👑 「เปิดแอด/ปิดแอด」
👑 「เปิดเข้า/ปิดเข้า」
👑 「เข้าแชท/ออกแชท」
👑 「เปิดอ่าน/ปิดอ่าน」
👑 「เปิดติก/ปิดติก」
👑 「เปิดแทค/ปิดแทค」
👑 「เปิดคท/ปิดคท」
👑 「เปิดติก/ปิดติก」
👑 「เปิดเชิญ/ปิดเชิญ」
👑 「เปิดมุดลิ้ง/ปิดมุดลิ้ง」
👑 「เปิดป้องลิ้ง/ปิดป้องกันลิ้ง」
👑 「เปิดป้องกัน/ปิดป้องกัน
"""
    return helpMessageBot
def lineBot(op):
    try:
        if op.type == 0:
            return
        #if op.type == 5:
        if op.type == 5:
            if settings["autoAdd"] == True:
                cl.blockContact(op.param1)
        if op.type == 13:
            print((op.param1))
            print((op.param2))
            print((op.param3))
            if clMID in op.param3:
                G = cl.getGroup(op.param1)
                if settings["autoJoin"] == True:
                    if settings["autoCancel"]["on"] == True:
                        if len(G.members) <= settings["autoCancel"]["members"]:
                            cl.rejectGroupInvitation(op.param1)
                        else:
                            cl.acceptGroupInvitation(op.param1)
                    else:
                        cl.acceptGroupInvitation(op.param1)
                elif settings["autoCancel"]["on"] == True:
                    if len(G.members) <= settings["autoCancel"]["members"]:
                        cl.rejectGroupInvitation(op.param1)
            else:
                Inviter = op.param3.replace("",',')
                InviterX = Inviter.split(",")
                matched_list = []
                for tag in settings["blacklist"]:
                    matched_list+=[str for str in InviterX if str == tag]
                if matched_list == []:
                    pass
                else:
                    cl.cancelGroupInvitation(op.param1, matched_list)
                    
            if mid in op.param3:
                if settings["AutoJoin"] == True:
                    cl.acceptGroupInvitation(op.param1)
                else:
                    cl.rejectGroupInvitation(op.param1)
            else:
                if settings["AutoCancel"] == True:
                    if op.param3 in admin:
                        pass
                    else:
                        cl.cancelGroupInvitation(op.param1, [op.param3])
                else:
                    if op.param3 in wait["blacklist"]:
                        cl.cancelGroupInvitation(op.param1, [op.param3])
                        cl.sendText(op.param1, "Itu kicker jgn di invite!")
                    else:
                        pass
                
        if op.type == 11:
            group = cl.getGroup(op.param1)
            contact = cl.getContact(op.param2)
            print ("[11] NOTIFIED ADD GROUP: " + str(group.name) + "\n" + op.param1 + "\n名字: " + contact.displayName)
            if settings["qrprotect"] == True:
                if op.param2 in admin:
                    pass
                else:
                    gs = cl.getGroup(op.param1)
                    cl.kickoutFromGroup(op.param1,[op.param2])
                    gs.preventJoinByTicket = True
                    cl.updateGroup(gs)
        if op.type == 13:
            contact1 = cl.getContact(op.param2)
            contact2 = cl.getContact(op.param3)
            group = cl.getGroup(op.param1)
            print ("[ 13 ] NOTIFIED INVITE GROUP: " + str(group.name) + "\n邀請者: " + contact1.displayName + "\n被邀請者" + contact2.displayName)
            if settings["inviteprotect"] == True:
                if op.param2 in admin:
                    pass
                else:
                    cl.cancelGroupInvitation(op.param3)
            if clMID in op.param3:
                cl.acceptGroupInvitation(op.param1)
        if op.type == 19:
            contact1 = cl.getContact(op.param2)
            group = cl.getGroup(op.param1)
            contact2 = cl.getContact(op.param3)
            print ("[19]NOTIFIED KICK GROUP: " + str(group.name) + "\n" + op.param1 +"\n踢人者: " + contact1.displayName + "\nMid: " + contact1.mid + "\n被踢者" + contact2.displayName + "\nMid:" + contact2.mid )
            if settings["protect"] == True:
                if op.param2 in admin:
                    pass
                else:
                    print ("[19]NOTIFIED KICK GROUP: " + str(group.name) +"\n踢人者: " + contact.displayName + "\nMid: " + contact.mid + "\n\n")
                    cl.kickoutFromGroup(op.param1,[op.param2])
            else:
                pass
            if mid2 in op.param3:
                if op.param2 in admin:
                    pass
                else:
                    cl.kickoutFromGroup(op.param1,[op.param2])
                    settings["blacklist"][op.param2] = True
                    group = cl.getGroup(op.param1)
                    try:
                        group.preventedJoinByTicket = False
                        cl.updateGroup(group)
                        str1 = cl.reissueGroupTicket(op.param1)
                    except Exception as e:
                        print(e)
                    cl.sendMessage(mid2, "/jgurlx gid: " + op.param1 + " gid " + "url: http://line.me/R/ti/g/" + str1 + " url")
        if op.type == 24:
            print ("[ 24 ] NOTIFIED LEAVE ROOM")
            if settings["autoLeave"] == True:
                cl.leaveRoom(op.param1)
        if op.type == 1:
            print ("[1]更新配置文件")
        if op.type == 26 or op.type == 25:
            msg = op.message
            text = msg.text
            msg_id = msg.id
            receiver = msg.to
            sender = msg._from
            if msg.toType == 0:
                if sender != cl.profile.mid:
                    to = sender
                else:
                    to = receiver
            else:
                to = receiver
            if msg.contentType == 13:
                if settings["contact"] == True:
                    msg.contentType = 0
                    if 'displayName' in msg.contentMetadata:
                        contact = cl.getContact(msg.contentMetadata["mid"])
                        try:
                            cu = cl.getProfileCoverURL(msg.contentMetadata["mid"])
                        except:
                            cu = ""
                            cl.sendMessage(msg.to,"[displayName]:\n" + msg.contentMetadata["displayName"] + "\n[mid]:\n" + msg.contentMetadata["mid"] + "\n[statusMessage]:\n" + contact.statusMessage + "\n[pictureStatus]:\nhttp://dl.profile.line-cdn.net/" + contact.pictureStatus + "\n[coverURL]:\n" + str(cu))
                    else:
                        contact = cl.getContact(msg.contentMetadata["mid"])
                        try:
                            cu = cl.getProfileCoverURL(msg.contentMetadata["mid"])
                        except:
                            cu = ""
                        cl.sendMessage(msg.to,"[displayName]:\n" + contact.displayName + "\n[mid]:\n" + msg.contentMetadata["mid"] + "\n[statusMessage]:\n" + contact.statusMessage + "\n[pictureStatus]:\nhttp://dl.profile.line-cdn.net/" + contact.pictureStatus + "\n[coverURL]:\n" + str(cu))
            elif msg.contentType == 16:
                if settings["timeline"] == True:
                    msg.contentType = 0
                    msg.text = "post URL\n" + msg.contentMetadata["postEndUrl"]
                    cl.sendMessage(msg.to,msg.text)
            if msg.contentType == 0:
              if sender in admin:
                if text is None:
                    return
                if text.lower() == 'คำสั่ง':
                    helpMessage = helpmessage()
                    cl.sendMessage(to, str(helpMessage))
                    cl.sendContact(to, "")
                elif text.lower() == 'ลูกเล่น':
                    helpMessageTag = helpmessagetag()
                    cl.sendMessage(to, str(helpMessageTag))
                elif text.lower() == 'คำสั่งเตะ':
                    helpMessageKick = helpmessagekick()
                    cl.sendMessage(to, str(helpMessageKick))
                elif text.lower() == 'helpbot':
                    helpMessageBot = helpMessageBot()
                    cl.sendMessage(to, str(helpMessageBot))
                elif "Fbc:" in msg.text:
                    bctxt = text.replace("Fbc:","")
                    t = cl.getAllContactIds()
                    for manusia in t:
                        cl.sendMessage(manusia,(bctxt))
                elif "Gbc:" in msg.text:
                    bctxt = text.replace("Gbc:","")
                    n = cl.getGroupIdsJoined()
                    for manusia in n:
                        cl.sendMessage(manusia,(bctxt))
                elif 'invitebot' in text.lower():
                    if msg.toType == 2:
                        group = cl.getGroup(to)
                        try:
                            group.preventedJoinByTicket = False
                            cl.updateGroup(group)
                            str1 = cl.reissueGroupTicket(to)
                        except Exception as e:
                                print(e)
                        cl.sendMessage(mid2, "/jgurlx gid: " + msg.to + " gid " + "url: http://line.me/R/ti/g/" + str1 + " url")
                elif text.startswith("/jgurlx"):
                        str1 = find_between_r(msg.text, "gid: ", " gid")
                        str2 = find_between_r(msg.text, "url: http://line.me/R/ti/g/", " url")
                        print("1")
                        cl.acceptGroupInvitationByTicket(str1, str2)
                        JoinedGroups.append(str1)
                        group = cl.getGroup(str1)
                        try:
                            cl.reissueGroupTicket(str1)
                            group.preventedJoinByTicket = True
                            cl.updateGroup(group)
                        except Exception as e:
                            print(e)
                elif "ล้อเล่น " in msg.text:
                    Ri0 = text.replace("ล้อเล่น ","")
                    Ri1 = Ri0.rstrip()
                    Ri2 = Ri1.replace("@","")
                    Ri3 = Ri2.rstrip()
                    _name = Ri3
                    gs = cl.getGroup(msg.to)
                    targets = []
                    for s in gs.members:
                        if _name in s.displayName:
                            targets.append(s.mid)
                    if targets == []:
                        pass
                    else:
                        for target in targets:
                            if target in admin:
                                pass
                            else:
                                try:
                                    cl.kickoutFromGroup(to,[target])
                                    cl.findAndAddContactsByMid(target)
                                    cl.inviteIntoGroup(to,[target])
                                except:
                                    pass
                elif "Uk " in msg.text:
                    midd = text.replace("Uk ","")
                    cl.kickoutFromGroup(to,[midd])
                elif "ปลิว " in msg.text:
                    key = eval(msg.contentMetadata["MENTION"])
                    key["MENTIONEES"][0]["M"]
                    targets = []
                    for x in key["MENTIONEES"]:
                        targets.append(x["M"])
                    for target in targets:
                        if target in admin:
                            pass
                        else:
                            try:
                                cl.kickoutFromGroup(to,[target])
                            except:
                                pass
                elif "ส่งแขก " in msg.text:
                    Mk0 = text.replace("ส่งแขก ","")
                    Mk1 = Mk0.rstrip()
                    Mk2 = Mk1.replace("@","")
                    Mk3 = Mk2.rstrip()
                    _name = Mk3
                    gs = cl.getGroup(to)
                    targets = []
                    for s in gs.members:
                        if _name in s.displayName:
                            targets.append(s.mid)
                    if targets == []:
                        pass
                    else:
                        for target in targets:
                            if target in admin:
                                pass
                            else:
                                try:
                                    cl.kickoutFromGroup(to,[target])
                                except:
                                    pass
                elif "Nk " in msg.text:
                    _name = text.replace("Nk ","")
                    gs = cl.getGroup(to)
                    targets = []
                    for g in gs.members:
                        if _name in g.displayName:
                            targets.append(g.mid)
                    if targets == []:
                        pass
                    else:
                        for target in targets:
                            if target in admin:
                                pass
                            else:
                                try:
                                    cl.kickoutFromGroup(to,[target])
                                except:
                                    pass
                elif "มองไม่เห็น" in msg.text:
                    gs = cl.getGroup(to)
                    targets = []
                    for g in gs.members:
                        if g.displayName in "":
                            targets.append(g.mid)
                    if targets == []:
                        pass
                    else:
                        for target in targets:
                            if target in admin:
                                pass
                            else:
                                try:
                                    cl.kickoutFromGroup(to,[target])
                                except:
                                    pass
                elif "Vk:" in text:
                    midd = msg.text.replace("Vk:","")
                    cl.kickoutFromGroup(msg.to,[midd])
                    cl.findAndAddContactsByMid(midd)
                    cl.inviteIntoGroup(msg.to,[midd])
                    cl.cancelGroupInvitation(msg.to,[midd])
                elif "ไปหำ " in msg.text:
                        vkick0 = msg.text.replace("ไปหำ ","")
                        vkick1 = vkick0.rstrip()
                        vkick2 = vkick1.replace("@","")
                        vkick3 = vkick2.rstrip()
                        _name = vkick3
                        gs = cl.getGroup(msg.to)
                        targets = []
                        for s in gs.members:
                            if _name in s.displayName:
                                targets.append(s.mid)
                        if targets == []:
                            pass
                        else:
                            for target in targets:
                                try:
                                    cl.kickoutFromGroup(msg.to,[target])
                                    cl.findAndAddContactsByMid(target)
                                    cl.inviteIntoGroup(msg.to,[target])
                                    cl.cancelGroupInvitation(msg.to,[target])
                                except:
                                    pass
                elif "NT " in msg.text:
                    _name = text.replace("NT ","")
                    gs = cl.getGroup(to)
                    targets = []
                    net_ = ""
                    for g in gs.members:
                        if _name in g.displayName:
                            targets.append(g.mid)
                    if targets == []:
                        cl.sendMessage(to, "這個群組沒有這個人")
                    else:
                        for target in targets:
                            try:
                                sendMessageWithMention(to,target)
                            except:
                                pass
                elif text.lower() == 'แทคล่องหน':
                    gs = cl.getGroup(to)
                    targets = []
                    for g in gs.members:
                        if g.displayName in "":
                            targets.append(g.mid)
                    if targets == []:
                        cl.sendMessage(to, "😱😱ไม่พบคนใส่ล่องหน😱😱")
                    else:
                        mc = ""
                        for target in targets:
                            mc += sendMessageWithMention(to,target) + "\n"
                        cl.sendMessage(to, mc)
                elif text.lower() == 'ไอดีล่องหน':
                    gs = cl.getGroup(to)
                    lists = []
                    for g in gs.members:
                        if g.displayName in "":
                            lists.append(g.mid)
                    if lists == []:
                        cl.sendMessage(to, "😱😱ไม่พบMidล่องหน😱😱")
                    else:
                        mc = ""
                        for mi_d in lists:
                            mc += "👑->" + mi_d + "\n"
                        cl.sendMessage(to,mc)
                elif text.lower() == 'ล่องหน':
                    gs = cl.getGroup(to)
                    lists = []
                    for g in gs.members:
                        if g.displayName in "":
                            lists.append(g.mid)
                    if lists == []:
                        cl.sendMessage(to, "😱😱ไม่พบคทล่องหน😱😱")
                    else:
                        for ls in lists:
                            contact = cl.getContact(ls)
                            mi_d = contact.mid
                            cl.sendContact(to, mi_d)
                elif "Mc " in msg.text:
                    mmid = msg.text.replace("Mc ","")
                    cl.sendContact(to, mmid)
                elif "Sc " in msg.text:
                    ggid = msg.text.replace("Sc ","")
                    group = cl.getGroup(ggid)
                    try:
                        gCreator = group.creator.displayName
                    except:
                        gCreator = "Tidak ditemukan"
                    if group.invitee is None:
                        gPending = "0"
                    else:
                        gPending = str(len(group.invitee))
                    if group.preventedJoinByTicket == True:
                        gQr = "Tertutup"
                        gTicket = "Tidak ada"
                    else:
                        gQr = "Terbuka"
                        gTicket = "https://cl.me/R/ti/g/{}".format(str(cl.reissueGroupTicket(group.id)))
                    path = "http://dl.profile.line-cdn.net/" + group.pictureStatus
                    ret_ = "╔══[ ข้อมูลกลุ่ม ]"
                    ret_ += "\n╠ ชื่อกลุ่ม : {}".format(str(group.name))
                    ret_ += "\n╠ ไอดีกลุ่ม : {}".format(group.id)
                    ret_ += "\n╠ คนสร้าง : {}".format(str(gCreator))
                    ret_ += "\n╠ สมาชิกกลุ่ม : {}".format(str(len(group.members)))
                    ret_ += "\n╠ ค้างเชิญ : {}".format(gPending)
                    ret_ += "\n╠ ลิ้งกลุ่มเปิดมั้ย : {}".format(gQr)
                    ret_ += "\n╠ ลิ้ง : {}".format(gTicket)
                    ret_ += "\n╚══[ 👑ŤỂÄΜ ж βǾŦ👑฿Ǿ¥👑 ]"
                    cl.sendMessage(to, str(ret_))
                    cl.sendImageWithURL(to, path)
                elif msg.text in ["cancel","Cancel"]:
                  if msg.toType == 2:
                    X = cl.getGroup(msg.to)
                    if X.invitee is not None:
                        gInviMids = (contact.mid for contact in X.invitee)
                        ginfo = cl.getGroup(msg.to)
                        sinvitee = str(len(ginfo.invitee))
                        start = time.time()
                        for cancelmod in gInviMids:
                            cl.cancelGroupInvitation(msg.to, [cancelmod])
                        elapsed_time = time.time() - start
                        cl.sendMessage(to, "已取消完成\n取消時間: %s秒" % (elapsed_time))
                        cl.sendMessage(to, "取消人數:" + sinvitee)
                    else:
                        cl.sendMessage(to, "沒有任何人在邀請中！！")
                elif text.lower() == '/ลบรัน':
                    gid = cl.getGroupIdsInvited()
                    start = time.time()
                    for i in gid:
                        cl.rejectGroupInvitation(i)
                    elapsed_time = time.time() - start
                    cl.sendMessage(to, "ลบรันเสร็จแล้วขอรับ")
                   # cl.sendMessage(to, "取消時間: %s秒" % (elapsed_time))
                elif "Gn " in msg.text:
                    if msg.toType == 2:
                        X = cl.getGroup(msg.to)
                        X.name = msg.text.replace("Gn ","")
                        cl.updateGroup(X)
                    else:
                        cl.sendMessage(msg.to,"เปลื่ยนชื่อกลุ่มแล้วขอรับ")
                elif "Gc" in msg.text:
                    if msg.toType == 2:
                        key = eval(msg.contentMetadata["MENTION"])
                        u = key["MENTIONEES"][0]["M"]
                        contact = cl.getContact(u)
                        cu = cl.getProfileCoverURL(mid=u)
                        try:
                            cl.sendMessage(msg.to,"displayName:\n" + contact.displayName + "\n\ndisplayName:\n" + contact.mid + "\n\n個性簽名:\n" + contact.statusMessage + "\n\n頭貼網址 :\nhttp://dl.profile.line-cdn.net/" + contact.pictureStatus + "\n\n封面網址 :\n" + str(cu))
                        except:
                            cl.sendMessage(msg.to,"displayName:\n" + contact.displayName + "\n\ndisplayName:\n" + contact.mid + "\n\n個性簽名:\n" + contact.statusMessage + "\n\n封面網址:\n" + str(cu))
                elif "Inv " in msg.text:
                    midd = msg.text.replace("Inv ","")
                    cl.findAndAddContactsByMid(midd)
                    cl.inviteIntoGroup(msg.to,[midd])
                elif "ดำ" in msg.text:
                    if msg.toType == 2:
                        print ("[Ban] 成功")
                        key = eval(msg.contentMetadata["MENTION"])
                        key["MENTIONEES"][0]["M"]
                        targets = []
                        for x in key["MENTIONEES"]:
                            targets.append(x["M"])
                        if targets == []:
                            pass
                        else:
                            for target in targets:
                                try:
                                    settings["blacklist"][target] = True
                                    cl.sendMessage(to, "😈😈เพิ้มในบันชีหนังหมา😈😈")
                                except:
                                    pass
                elif "Unban" in msg.text:
                    if msg.toType == 2:
                        print ("[UnBan] 成功")
                        key = eval(msg.contentMetadata["MENTION"])
                        key["MENTIONEES"][0]["M"]
                        targets = []
                        for x in key["MENTIONEES"]:
                            targets.append(x["M"])
                        if targets == []:
                            pass
                        else:
                            for target in targets:
                                try:
                                    del settings["blacklist"][target]
                                    cl.sendMessage(to, "😈😈เอาออกจากบันชีหนังหมาแล้ว😈😈")
                                except:
                                    pass
                elif text.lower() == 'ล้างหนังหมา':
                    for mi_d in settings["blacklist"]:
                        settings["blacklist"] = {}
                    cl.sendMessage(to, "😊😊ล้างบันชีหนังหมาแล้ว😊😊")
                elif text.lower() == 'พวกดื้อ':
                    if settings["blacklist"] == {}:
                        cl.sendMessage(to, "😁😁รายชื่อคนติดบัญชีหนังหมา😁😁")
                    else:
                        cl.sendMessage(to, "😁😁รายชื่อคนติดบัญชีหนังหมา😁😁")
                        mc = ""
                        for mi_d in settings["blacklist"]:
                            mc += "👑->" + cl.getContact(mi_d).displayName + "\n"
                        cl.sendMessage(to, mc)
                elif text.lower() == 'banmid':
                    if settings["blacklist"] == {}:
                        cl.sendMessage(to, "😊😊midคนติดดำ😊😊")
                    else:
                        cl.sendMessage(to, "😊😊midคนติดดำ😊😊")
                        mc = ""
                        for mi_d in settings["blacklist"]:
                            mc += "->" + cl.getContact(mi_d).mid + "\n"
                        cl.sendMessage(to, mc)
	        
                elif text.lower() == 'ไปเส้':
                    if msg.toType == 2:
                        group = cl.getGroup(to)
                        gMembMids = [contact.mid for contact in group.members]
                        matched_list = []
                        for tag in settings["blacklist"]:
                            matched_list+=filter(lambda str: str == tag, gMembMids)
                        if matched_list == []:
                            print ("1")
                            cl.sendMessage(to, "😠😠หงอยท้องไปดิ😠😠")
                            return
                        klist = [cl]
                        kickers = random.choice(klist)
                        for jj in matched_list:
                            kickers.kickoutFromGroup(to, [jj])
                        cl.sendMessage(to, "😠😠หงอยท้องไปดิ😠😠")
                elif "/invitemeto:" in msg.text:
                    gid = msg.text.replace("/invitemeto:","")
                    if gid == "":
                        cl.sendMessage(to,"請輸入群組ID")
                    else:
                        try:
                            cl.findAndAddContactsByMid(msg.from_)
                            cl.inviteIntoGroup(gid,[msg.from_])
                        except:
                            cl.sendMessage(to,"我不在那個群組裡")
                elif msg.text in ["離開全部群組"]:
                    gid = cl.getGroupIdsJoined()
                    for i in gid:
                        cl.leaveGroup(i)
                        cl.sendText(msg.to,"已離開全部群組")
                elif msg.text in ["SR","Setread"]:
                    cl.sendMessage(msg.to, "設置已讀點")
                    try:
                        del wait2['readPoint'][msg.to]
                        del wait2['readMember'][msg.to]
                    except:
                        pass
                    now2 = datetime.now()
                    wait2['readPoint'][msg.to] = msg.id
                    wait2['readMember'][msg.to] = ""
                    wait2['setTime'][msg.to] = datetime.strftime(now2,"%H:%M")
                    wait2['ROM'][msg.to] = {}
                    print ("設置已讀點")
                elif msg.text in ["LR","Lookread"]:
                    if msg.to in wait2['readPoint']:
                        print ("查詢已讀")
                        if wait2["ROM"][msg.to].items() == []:
                            chiya = ""
                        else:
                            chiya = ""
                            for rom in wait2["ROM"][msg.to].items():
                                chiya += rom[1] + "\n"
                        cl.sendMessage(msg.to, "||已讀順序||%s\n\n||已讀的人||\n\n%s\n[%s]" % (wait2['readMember'][msg.to],chiya,setTime[msg.to]))
                    else:
                        cl.sendMessage(msg.to, "請輸入SR設置已讀點")
                elif text.lower() == 'readset':
                    try:
                        del cctv['point'][msg.to]
                        del cctv['sidermem'][msg.to]
                        del cctv['cyduk'][msg.to]
                    except:
                        pass
                    cctv['point'][msg.to] = msg.id
                    cctv['sidermem'][msg.to] = ""
                    cctv['cyduk'][msg.to]=True
                elif text.lower() == 'offread':
                    if msg.to in cctv['point']:
                        cctv['cyduk'][msg.to]=False
                        cl.sendMessage(to, cctv['sidermem'][msg.to])
                    else:
                        cl.sendMessage(to, "readset")
                elif msg.text in ["เชคเพื่อน"]:
                    anl = cl.getAllContactIds()
                    ap = ""
                    for q in anl:
                        ap += "• "+cl.getContact(q).displayName + "\n"
                    cl.sendMessage(msg.to,"「 เพื่อนทั้งหมด 」\n"+ap+"ทั่งหมด : "+str(len(anl)))
                elif text.lower() == 'speed':
                    time0 = timeit.timeit('"-".join(str(n) for n in range(100))', number=50000)
                    str1 = str(time0)
                    start = time.time()
                    cl.sendMessage(to,'👑ŤỂÄΜ ж βǾŦ👑฿Ǿ¥👑\n' + str1 + '👑')
                    elapsed_time = time.time() - start
                    cl.sendMessage(to,'👑ŤỂÄΜ ж βǾŦ👑฿Ǿ¥👑\n' + format(str(elapsed_time)) + '👑')
                elif text.lower() == 'rebot':
                    cl.sendMessage(to, "重新啟動")
                    restartBot()
                elif text.lower() == 'เชคบอท':
                    timeNow = time.time()
                    runtime = timeNow - botStart
                    runtime = format_timespan(runtime)
                    cl.sendMessage(to, "ใช่บอทมาเป็นเวลา {}".format(str(runtime)))
                elif text.lower() == 'ข้อมูล':
                    try:
                        arr = []
                        owner = "u800b5f33bdfebcc0f2f878ff5c712180"
                        creator = cl.getContact(owner)
                        contact = cl.getContact(clMID)
                        grouplist = cl.getGroupIdsJoined()
                        contactlist = cl.getAllContactIds()
                        blockedlist = cl.getBlockedContactIds()
                        ret_ = "╔══[ 👑ŤỂÄΜ ж βǾŦ👑฿Ǿ¥👑 ]"
                        ret_ += "\n╠ ชื่อ : {}".format(contact.displayName)
                        ret_ += "\n╠ กลุ่ม : {}".format(str(len(grouplist)))
                        ret_ += "\n╠ เพื่อน : {}".format(str(len(contactlist)))
                        ret_ += "\n╠ คนที่เราบล็อค : {}".format(str(len(blockedlist)))
                        ret_ += "\n╠══[ 👑ŤỂÄΜ ж βǾŦ👑฿Ǿ¥👑 ]"
                        ret_ += "\n╠ Version : Beta Test"
                        ret_ += "\n╠ ชื่อเรา : {}".format(creator.displayName)
                        ret_ += "\n╚══[ 👑ŤỂÄΜ ж βǾŦ👑฿Ǿ¥👑 ]"
                        cl.sendMessage(to, str(ret_))
                    except Exception as e:
                        cl.sendMessage(msg.to, str(e))

                elif text.lower() == 'เชคค่า':
                    try:
                        ret_ = "╔══[ 👑ŤỂÄΜ ж βǾŦ👑฿Ǿ¥👑 ]"
                        if settings["autoAdd"] == True: ret_ += "\n╠ รับแอดออโต้  ✅"
                        else: ret_ += "\n╠ รับแอดออโต้ ❌"
                        if settings["autoJoin"] == True: ret_ += "\n╠ เข้ารวมกล่มออโต้ ✅"
                        else: ret_ += "\n╠ เข้ารวมกล่มออโต้ ❌"
                        if settings["autoLeave"] == True: ret_ += "\n╠ ออกแชทรวม ✅"
                        else: ret_ += "\n╠ ออกแชทรวม ❌"
                        if settings["autoRead"] == True: ret_ += "\n╠ อ่านออโต้ ✅"
                        else: ret_ += "\n╠ อ่านออโต้ ❌"
                        if settings["inviteprotect"] == True: ret_ += "\n╠ ป้องกันเชิญ ✅"
                        else: ret_ += "\n╠ ป้องกันเชิญ ❌"
                        if settings["qrprotect"] == True: ret_ += "\n╠ ป้องกันลิ้ง ✅"
                        else: ret_ += "\n╠ ป้องกันลิ้ง ❌"
                        if settings["protect"] == True: ret_ += "\n╠ ป้องกัน ✅"
                        else: ret_ += "\n╠ ป้องกัน ❌"
                        if settings["checkSticker"] == True: ret_ += "\n╠ เช็คสติกเกอร์ ✅"
                        else: ret_ += "\n╠ เช็คสติกเกอร์ ❌"
                        if settings["detectMention"] == True: ret_ += "\n╠ ข้อความตอบกลับ ✅"
                        else: ret_ += "\n╠ ข้อความตอบกลับ ❌"
                        if settings["contact"] == True: ret_ += "\n╠ อ่านคอนแทค ✅"
                        else: ret_ += "\n╠ อ่านคอนแทค ❌"
                        if settings["reread"] == True: ret_ += "\n╠ อ่านออโต้ ✅"
                        else: ret_ += "\n╠ reread ❌"
                        ret_ += "\n╚══[ 👑ŤỂÄΜ ж βǾŦ👑฿Ǿ¥👑 ]"
                        cl.sendMessage(to, str(ret_))
                    except Exception as e:
                        cl.sendMessage(msg.to, str(e))
                elif text.lower() == 'เปิดแอด':
                    settings["autoAdd"] = True
                    cl.sendMessage(to, "😀😀เปิดออโต้บ๊อคแล้ว😀😀")
                elif text.lower() == 'ปิดแอด':
                    settings["autoAdd"] = False
                    cl.sendMessage(to, "😀😀ปิดออโต้บ๊อคแล้ว😀😀")
                elif text.lower() == 'เปิดเข้า':
                    settings["autoJoin"] = True
                    cl.sendMessage(to, "😀😀เปิดเข้ากลุ่มออโต้แล้ว😀😀")
                elif text.lower() == 'ปิดเข้า':
                    settings["autoJoin"] = False
                    cl.sendMessage(to, "😀😀ปิดเข้ากลุ่มออโต้แล้ว😀😀")
                elif text.lower() == 'ออกแชท':
                    settings["autoLeave"] = True
                    cl.sendMessage(to, "😀😀เปิดออกแชทรวมแล้ว😀😀")
                elif text.lower() == 'เข้าแชท':
                    settings["autoLeave"] = False
                    cl.sendMessage(to, "😀😀ปิดออกแชทรวมแล้ว😀😀")
                elif text.lower() == 'เปิดอ่าน':
                    settings["autoRead"] = True
                    cl.sendMessage(to, "😊😊เปิดอ่านเรียบร้อยครับ😊😊")
                elif text.lower() == 'ปิดอ่าน':
                    settings["autoRead"] = False
                    cl.sendMessage(to, "😊😊ปิดอ่านเรียบร้อยครับ😊😊")
                elif text.lower() == 'เปิดติก':
                    settings["checkSticker"] = True
                    cl.sendMessage(to, "😊😊เปิดเช็คโค๊ชสติกเกอร์เรียบร้อยครับ😊😊")
                elif text.lower() == 'ปิดติก':
                    settings["checkSticker"] = False
                    cl.sendMessage(to, "😊😊ปิดเช็คโค๊ชสติกเกอร์เรียบร้อยครับ😊😊")
                elif text.lower() == 'เปิดแทค':
                    settings["detectMention"] = True
                    cl.sendMessage(to, "😊😊เปิดแทคแล้ว😀😀")
                elif text.lower() == 'ปิดแทค':
                    settings["detectMention"] = False
                    cl.sendMessage(to, "😊😊ปิดแทคแล้ว😀😀")
                elif text.lower() == 'clonecontact':
                    settings["copy"] = True
                    cl.sendMessage(to, "clonecontact on")
                elif text.lower() == 'เปิดคท':
                    settings["contact"] = True
                    cl.sendMessage(to, "😊😊เปิดอ่านคอนแทคเรียบร้อย😊😊")
                elif text.lower() == 'ปิดคท':
                    settings["contact"] = False
                    cl.sendMessage(to, "😊😊ปิดอ่านคอนแทคเรียบร้อย😊😊")
                elif text.lower() == 'เปิดมุดลิ้ง':
                    settings["autoJoinTicket"] = True
                    cl.sendMessage(to, "😊😊เปิดมุดลิ้งออโต้เรียบร้อยครับ😊😊")
                elif text.lower() == 'ปิดมุดลิ้ง':
                    settings["autoJoinTicket"] = False
                    cl.sendMessage(to, "😊😊ปิดมุดลิ้งออโต้เรียบร้อยครับ😊😊")
                elif text.lower() == 'เปิดเชิญ':
                    settings["inviteprotect"] = True
                    cl.sendMessage(to, "😊😊เปิดอนุญาตให้เชิญคนได้เรียบร้อยครับ😊😊")
                elif text.lower() == 'ปิดเชิญ':
                    settings["inviteprotect"] = False
                    cl.sendMessage(to, "😊😊ปิดอนุญาตให้เชิญคนได้เรียบร้อยครับ😊😊")
                elif text.lower() == 'เปิดป้องกันลิ้ง':
                    settings["qrprotect"] = True
                    cl.sendMessage(to, "😊😊เปิดป้องกันลิ้งเรียบร้อยครับ😊😊")
                elif text.lower() == 'ปิดป้องกันลิ้ง':
                    settings["qrprotect"] = False
                    cl.sendMessage(to, "😊😊ปิดป้องกันลิ้งเรียบร้อยครับ😊😊")
                elif text.lower() == 'เปิดป้องกัน':
                    settings["protect"] = True
                    cl.sendMessage(to, "😊😊เปิดป้องกันห้องเรียบร้อยครับ😊😊")
                elif text.lower() == 'ปิดป้องกัน':
                    settings["protect"] = False
                    cl.sendMessage(to, "😊😊ปิดป้องกันห้องเรียบร้อยครับ😊😊")
                elif text.lower() == 'เปิดอ่าน':
                    settings["reread"] = True
                    cl.sendMessage(to, "😊😊เปิดอ่านข้อความออโต้เรียบร้อยครับ😊😊")
                elif text.lower() == 'ปิดอ่าน':
                    settings["reread"] = False
                    cl.sendMessage(to, "😊😊เปิดอ่านข้อความออโต้เรียบร้อยครับ😊😊")
                elif text.lower() == 'คท':
                    sendMessageWithMention(to, sender)
                    cl.sendContact(to, sender)
                elif text.lower() == 'ไอดีเรา':
                    cl.sendMessage(msg.to,"[MID]\n" +  sender)
                elif text.lower() == 'ชื่อเรา':
                    me = cl.getContact(sender)
                    cl.sendMessage(msg.to,"[DisplayName]\n" + me.displayName)
                elif text.lower() == 'ตัสเรา':
                    me = cl.getContact(sender)
                    cl.sendMessage(msg.to,"[StatusMessage]\n" + me.statusMessage)
                elif text.lower() == 'รูปเรา':
                    me = cl.getContact(sender)
                    cl.sendImageWithURL(msg.to,"http://dl.profile.line-cdn.net/" + me.pictureStatus)
                elif text.lower() == 'myvideoprofile':
                    me = cl.getContact(sender)
                    cl.sendVideoWithURL(msg.to,"http://dl.profile.line-cdn.net/" + me.pictureStatus + "/vp")
                elif text.lower() == 'ปกเรา':
                    me = cl.getContact(sender)
                    cover = cl.getProfileCoverURL(sender)
                    cl.sendImageWithURL(msg.to, cover)
                elif msg.text.lower().startswith("คท "):
                    if 'MENTION' in msg.contentMetadata.keys()!= None:
                        names = re.findall(r'@(\w+)', text)
                        mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                        mentionees = mention['MENTIONEES']
                        lists = []
                        for mention in mentionees:
                            if mention["M"] not in lists:
                                lists.append(mention["M"])
                        for ls in lists:
                            contact = cl.getContact(ls)
                            mi_d = contact.mid
                            cl.sendContact(msg.to, mi_d)
                elif msg.text.lower().startswith("ไอดี "):
                    if 'MENTION' in msg.contentMetadata.keys()!= None:
                        names = re.findall(r'@(\w+)', text)
                        mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                        mentionees = mention['MENTIONEES']
                        lists = []
                        for mention in mentionees:
                            if mention["M"] not in lists:
                                lists.append(mention["M"])
                        ret_ = ""
                        for ls in lists:
                            ret_ += "" + ls
                        cl.sendMessage(msg.to, str(ret_))
                elif msg.text.lower().startswith("ชื่อ "):
                    if 'MENTION' in msg.contentMetadata.keys()!= None:
                        names = re.findall(r'@(\w+)', text)
                        mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                        mentionees = mention['MENTIONEES']
                        lists = []
                        for mention in mentionees:
                            if mention["M"] not in lists:
                                lists.append(mention["M"])
                        for ls in lists:
                            contact = cl.getContact(ls)
                            cl.sendMessage(msg.to, "[ Display Name ]\n" + contact.displayName)
                elif msg.text.lower().startswith("ตัส "):
                    if 'MENTION' in msg.contentMetadata.keys()!= None:
                        names = re.findall(r'@(\w+)', text)
                        mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                        mentionees = mention['MENTIONEES']
                        lists = []
                        for mention in mentionees:
                            if mention["M"] not in lists:
                                lists.append(mention["M"])
                        for ls in lists:
                            contact = cl.getContact(ls)
                            cl.sendMessage(msg.to, "[ Status Message ]\n{}" + contact.statusMessage)
                elif msg.text.lower().startswith("รูป "):
                    if 'MENTION' in msg.contentMetadata.keys()!= None:
                        names = re.findall(r'@(\w+)', text)
                        mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                        mentionees = mention['MENTIONEES']
                        lists = []
                        for mention in mentionees:
                            if mention["M"] not in lists:
                                lists.append(mention["M"])
                        for ls in lists:
                            path = "http://dl.profile.line-cdn.net/" + cl.getContact(ls).pictureStatus
                            cl.sendImageWithURL(msg.to, str(path))
                elif msg.text.lower().startswith("videoprofile "):
                    if 'MENTION' in msg.contentMetadata.keys()!= None:
                        names = re.findall(r'@(\w+)', text)
                        mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                        mentionees = mention['MENTIONEES']
                        lists = []
                        for mention in mentionees:
                            if mention["M"] not in lists:
                                lists.append(mention["M"])
                        for ls in lists:
                            path = "http://dl.profile.line-cdn.net/" + cl.getContact(ls).pictureStatus + "/vp"
                            cl.sendImageWithURL(msg.to, str(path))
                elif msg.text.lower().startswith("ปก "):
                    if 'MENTION' in msg.contentMetadata.keys()!= None:
                        if 'MENTION' in msg.contentMetadata.keys()!= None:
                            names = re.findall(r'@(\w+)', text)
                            mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                            mentionees = mention['MENTIONEES']
                            lists = []
                            for mention in mentionees:
                                if mention["M"] not in lists:
                                    lists.append(mention["M"])
                            for ls in lists:
                                path = cl.getProfileCoverURL(ls)
                                cl.sendImageWithURL(msg.to, str(path))
                elif msg.text.lower().startswith("copy "):
                    if 'MENTION' in msg.contentMetadata.keys()!= None:
                        names = re.findall(r'@(\w+)', text)
                        mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                        mentionees = mention['MENTIONEES']
                        for mention in mentionees:
                            contact = mention["M"]
                            break
                        try:
                            cl.cloneContactProfile(contact)
                            cl.sendMessage(msg.to, "🤗🤗ก็อปคนอื่นสำเร็จแล้ว🤗🤗")
                        except:
                            cl.sendMessage(msg.to, "🤗🤗ก็อปคนอื่นสำเร็จแล้ว🤗🤗")
                            
                elif text.lower() == 'คืนร่าง':
                    try:
                        clProfile.displayName = str(myProfile["displayName"])
                        clProfile.statusMessage = str(myProfile["statusMessage"])
                        clProfile.pictureStatus = str(myProfile["pictureStatus"])
                        cl.updateProfileAttribute(8, clProfile.pictureStatus)
                        cl.updateProfile(clProfile)
                        cl.sendMessage(msg.to, "🤗🤗กลับร่างเดิมเรียบร้อย🤗🤗")
                    except:
                        cl.sendMessage(msg.to, "🤗🤗กลับร่างเดิมเรียบร้อย🤗🤗")
                        
                elif msg.text.lower().startswith("mimicadd "):
                    targets = []
                    key = eval(msg.contentMetadata["MENTION"])
                    key["MENTIONEES"][0]["M"]
                    for x in key["MENTIONEES"]:
                        targets.append(x["M"])
                    for target in targets:
                        try:
                            settings["mimic"]["target"][target] = True
                            cl.sendMessage(msg.to,"Target ditambahkan！")
                            break
                        except:
                            cl.sendMessage(msg.to,"Added Target Fail !")
                            break
                elif msg.text.lower().startswith("mimicdel "):
                    targets = []
                    key = eval(msg.contentMetadata["MENTION"])
                    key["MENTIONEES"][0]["M"]
                    for x in key["MENTIONEES"]:
                        targets.append(x["M"])
                    for target in targets:
                        try:
                            del settings["mimic"]["target"][target]
                            cl.sendMessage(msg.to,"Target dihapuskan！")
                            break
                        except:
                            cl.sendMessage(msg.to,"Deleted Target Fail !")
                            break
                elif text.lower() == 'mimiclist':
                    if settings["mimic"]["target"] == {}:
                        cl.sendMessage(msg.to,"Tidak Ada Target")
                    else:
                        mc = "╔══[ Mimic List ]"
                        for mi_d in settings["mimic"]["target"]:
                            mc += "\n╠ "+cl.getContact(mi_d).displayName
                        cl.sendMessage(msg.to,mc + "\n╚══[ Finish ]")
                    
                elif "mimic" in msg.text.lower():
                    sep = text.split(" ")
                    mic = text.replace(sep[0] + " ","")
                    if mic == "on":
                        if settings["mimic"]["status"] == False:
                            settings["mimic"]["status"] = True
                            cl.sendMessage(msg.to,"Reply Message on")
                    elif mic == "off":
                        if settings["mimic"]["status"] == True:
                            settings["mimic"]["status"] = False
                            cl.sendMessage(msg.to,"Reply Message off")
                elif text.lower() == 'คนสร้างกลุ่ม':
                    group = cl.getGroup(to)
                    GS = group.creator.mid
                    cl.sendContact(to, GS)
                elif text.lower() == 'ไอดีกลุ่ม':
                    gid = cl.getGroup(to)
                    cl.sendMessage(to, "[ID Group : ]\n" + gid.id)
                elif text.lower() == 'รูปกลุ่ม':
                    group = cl.getGroup(to)
                    path = "http://dl.profile.line-cdn.net/" + group.pictureStatus
                    cl.sendImageWithURL(to, path)
                elif text.lower() == 'ชื่อกลุ่ม':
                    gid = cl.getGroup(to)
                    cl.sendMessage(to, "[🤗🤗ชื่อกลุ่มที่เราอาศัยอยู่🤗🤗]\n" + gid.name)
                elif text.lower() == 'ลิ้งห้อง':
                    if msg.toType == 2:
                        group = cl.getGroup(to)
                        if group.preventedJoinByTicket == False:
                            ticket = cl.reissueGroupTicket(to)
                            cl.sendMessage(to, "[👑ŤỂÄΜ ж βǾŦ👑฿Ǿ¥👑]\nhttps://cl.me/R/ti/g/{}".format(str(ticket)))
                        else:
                            cl.sendMessage(to, "😀😀ต้องเปิดลิ้งห้องก่อนขอลิ้ง😀😀".format(str(settings["keyCommand"])))
                elif text.lower() == 'เปิดลิ้ง':
                    if msg.toType == 2:
                        G = cl.getGroup(to)
                        if G.preventedJoinByTicket == False:
                            cl.sendMessage(to, "😀😀ลิ้งห้องเปิดอยู่แล้ว😀😀")
                        else:
                            G.preventedJoinByTicket = False
                            cl.updateGroup(G)
                            cl.sendMessage(to, "😀😀คุณได้เปิดลิ้งห้องสำเร็จแล้ว😀😀")
                elif text.lower() == 'ปิดลิ้ง':
                    if msg.toType == 2:
                        G = cl.getGroup(to)
                        if G.preventedJoinByTicket == True:
                            cl.sendMessage(to, "😀😀ลิ้งห้องได้ปิดอยู่แล้ว😀😀")
                        else:
                            G.preventedJoinByTicket = True
                            cl.updateGroup(G)
                            cl.sendMessage(to, "😀😀คุณได้ปิดลิ้งห้องสำเร็จแล้ว😀😀")
                elif text.lower() == 'เชคข้อมูลกลุ่ม':
                    group = cl.getGroup(to)
                    try:
                        gCreator = group.creator.displayName
                    except:
                        gCreator = "Tidak ditemukan"
                    if group.invitee is None:
                        gPending = "0"
                    else:
                        gPending = str(len(group.invitee))
                    if group.preventedJoinByTicket == True:
                        gQr = "Tertutup"
                        gTicket = "Tidak ada"
                    else:
                        gQr = "Terbuka"
                        gTicket = "https://cl.me/R/ti/g/{}".format(str(cl.reissueGroupTicket(group.id)))
                    path = "http://dl.profile.line-cdn.net/" + group.pictureStatus
                    ret_ = "╔══[ ข้อมูลกลุ่ม ]"
                    ret_ += "\n╠ ชื่อห้อง : {}".format(str(group.name))
                    ret_ += "\n╠ ไอดีกลุ่ม : {}".format(group.id)
                    ret_ += "\n╠ ชื่อคนสร้าง : {}".format(str(gCreator))
                    ret_ += "\n╠ สมาชิกในกลุ่ม : {}".format(str(len(group.members)))
                    ret_ += "\n╠ ค้างเชิญ : {}".format(gPending)
                    ret_ += "\n╠ ลิ้งกลุ่มเปิดมั้ย : {}".format(gQr)
                    ret_ += "\n╠ ลิ้ง : {}".format(gTicket)
                    ret_ += "\n╚══[ 👑ŤỂÄΜ ж βǾŦ👑฿Ǿ¥👑 ]"
                    cl.sendMessage(to, str(ret_))
                    cl.sendImageWithURL(to, path)
                elif text.lower() == 'เชคคนในกลุ่ม':
                    if msg.toType == 2:
                        group = cl.getGroup(to)
                        ret_ = "╔══[ Member List]"
                        no = 0 + 1
                        for mem in group.members:
                            ret_ += "\n╠ {}. {}".format(str(no), str(mem.displayName))
                            no += 1
                        ret_ += "\n╚══[ Total： {} ]".format(str(len(group.members)))
                        cl.sendMessage(to, str(ret_))
                elif text.lower() == 'กลุ่มของเรา':
                        groups = cl.groups
                        ret_ = "╔══[ Group List ]"
                        no = 0 + 1
                        for gid in groups:
                            group = cl.getGroup(gid)
                            ret_ += "\n╠ {}. {} | {}".format(str(no), str(group.name), str(len(group.members)))
                            no += 1
                        ret_ += "\n╚══[ Total {} Groups ]".format(str(len(groups)))
                        cl.sendMessage(to, str(ret_))

                elif text.lower() == 'แทค':
                    group = cl.getGroup(msg.to)
                    nama = [contact.mid for contact in group.members]
                    k = len(nama)//100
                    for a in range(k+1):
                        txt = u''
                        s=0
                        b=[]
                        for i in group.members[a*100 : (a+1)*100]:
                            b.append({"S":str(s), "E" :str(s+6), "M":i.mid})
                            s += 7
                            txt += u'@Alin \n'
                        cl.sendMessage(to, text=txt, contentMetadata={u'MENTION': json.dumps({'MENTIONEES':b})}, contentType=0)
                        cl.sendMessage(to, "จำนวนสมาชิก {} คน".format(str(len(nama))))
                elif text.lower() == 'sn':
                    tz = pytz.timezone("Asia/Jakarta")
                    timeNow = datetime.now(tz=tz)
                    day = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday","Friday", "Saturday"]
                    hari = ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"]
                    bulan = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"]
                    hr = timeNow.strftime("%A")
                    bln = timeNow.strftime("%m")
                    for i in range(len(day)):
                        if hr == day[i]: hasil = hari[i]
                    for k in range(0, len(bulan)):
                        if bln == str(k): bln = bulan[k-1]
                    readTime = hasil + ", " + timeNow.strftime('%d') + " - " + bln + " - " + timeNow.strftime('%Y') + "\nJam : [ " + timeNow.strftime('%H:%M:%S') + " ]"
                    if msg.to in read['readPoint']:
                            try:
                                del read['readPoint'][msg.to]
                                del read['readMember'][msg.to]
                                del read['readTime'][msg.to]
                            except:
                                pass
                            read['readPoint'][msg.to] = msg.id
                            read['readMember'][msg.to] = ""
                            read['readTime'][msg.to] = datetime.now().strftime('%H:%M:%S')
                            read['ROM'][msg.to] = {}
                            with open('read.json', 'w') as fp:
                                json.dump(read, fp, sort_keys=True, indent=4)
                                cl.sendMessage(msg.to,"😊😊กำลังตรวจสอบคนแอบอ่านอยู่😊😊")
                    else:
                        try:
                            del read['readPoint'][msg.to]
                            del read['readMember'][msg.to]
                            del read['readTime'][msg.to]
                        except:
                            pass
                        read['readPoint'][msg.to] = msg.id
                        read['readMember'][msg.to] = ""
                        read['readTime'][msg.to] = datetime.now().strftime('%H:%M:%S')
                        read['ROM'][msg.to] = {}
                        with open('read.json', 'w') as fp:
                            json.dump(read, fp, sort_keys=True, indent=4)
                            cl.sendMessage(msg.to, "😊😊กำลังตรวจสอบคนแอบอ่านอยู่😊😊" + readTime)
                            
                elif text.lower() == 'sf':
                    tz = pytz.timezone("Asia/Jakarta")
                    timeNow = datetime.now(tz=tz)
                    day = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday","Friday", "Saturday"]
                    hari = ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"]
                    bulan = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"]
                    hr = timeNow.strftime("%A")
                    bln = timeNow.strftime("%m")
                    for i in range(len(day)):
                        if hr == day[i]: hasil = hari[i]
                    for k in range(0, len(bulan)):
                        if bln == str(k): bln = bulan[k-1]
                    readTime = hasil + ", " + timeNow.strftime('%d') + " - " + bln + " - " + timeNow.strftime('%Y') + "\nJam : [ " + timeNow.strftime('%H:%M:%S') + " ]"
                    if msg.to not in read['readPoint']:
                        cl.sendMessage(msg.to,"Lurking already off")
                    else:
                        try:
                            del read['readPoint'][msg.to]
                            del read['readMember'][msg.to]
                            del read['readTime'][msg.to]
                        except:
                              pass
                        cl.sendMessage(msg.to, "Delete reading point:\n" + readTime)
    
                elif text.lower() == 'sr':
                    tz = pytz.timezone("Asia/Jakarta")
                    timeNow = datetime.now(tz=tz)
                    day = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday","Friday", "Saturday"]
                    hari = ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"]
                    bulan = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"]
                    hr = timeNow.strftime("%A")
                    bln = timeNow.strftime("%m")
                    for i in range(len(day)):
                        if hr == day[i]: hasil = hari[i]
                    for k in range(0, len(bulan)):
                        if bln == str(k): bln = bulan[k-1]
                    readTime = hasil + ", " + timeNow.strftime('%d') + " - " + bln + " - " + timeNow.strftime('%Y') + "\n時間 : [ " + timeNow.strftime('%H:%M:%S') + " ]"
                    if msg.to in read["readPoint"]:
                        try:
                            del read["readPoint"][msg.to]
                            del read["readMember"][msg.to]
                            del read["readTime"][msg.to]
                        except:
                            pass
                        cl.sendMessage(msg.to, "Reset reading point:\n" + readTime)
                    else:
                        cl.sendMessage(msg.to, "Lurking belum diaktifkan ngapain di reset?")
                        
                elif text.lower() == 'r':
                    tz = pytz.timezone("Asia/Jakarta")
                    timeNow = datetime.now(tz=tz)
                    day = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday","Friday", "Saturday"]
                    hari = ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"]
                    bulan = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"]
                    hr = timeNow.strftime("%A")
                    bln = timeNow.strftime("%m")
                    for i in range(len(day)):
                        if hr == day[i]: hasil = hari[i]
                    for k in range(0, len(bulan)):
                        if bln == str(k): bln = bulan[k-1]
                    readTime = hasil + ", " + timeNow.strftime('%d') + " - " + bln + " - " + timeNow.strftime('%Y') + "\n時間 : [ " + timeNow.strftime('%H:%M:%S') + " ]"
                    if receiver in read['readPoint']:
                        if read["ROM"][receiver].items() == []:
                            cl.sendMessage(receiver,"[ คนที่อ่าน ]:\nNone")
                        else:
                            chiya = []
                            for rom in read["ROM"][receiver].items():
                                chiya.append(rom[1])
                            cmem = cl.getContacts(chiya)
                            zx = ""
                            zxc = ""
                            zx2 = []
                            xpesan = '[ คนที่อ่าน ]:\n'
                        for x in range(len(cmem)):
                            xname = str(cmem[x].displayName)
                            pesan = ''
                            pesan2 = pesan+"@c\n"
                            xlen = str(len(zxc)+len(xpesan))
                            xlen2 = str(len(zxc)+len(pesan2)+len(xpesan)-1)
                            zx = {'S':xlen, 'E':xlen2, 'M':cmem[x].mid}
                            zx2.append(zx)
                            zxc += pesan2
                        text = xpesan+ zxc + "\n[ อ่านเวลา ]: \n" + readTime
                        try:
                            cl.sendMessage(receiver, text, contentMetadata={'MENTION':str('{"MENTIONEES":'+json.dumps(zx2).replace(' ','')+'}')}, contentType=0)
                        except Exception as error:
                            print (error)
                        pass
                    else:
                        cl.sendMessage(receiver,"Lurking has not been set.")
                elif text.lower() == 'time':
                    tz = pytz.timezone("Asia/Makassar")
                    timeNow = datetime.now(tz=tz)
                    day = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday","Friday", "Saturday"]
                    hari = ["星期一", "星期二", "星期三", "星期五", "星期四", "星期五", "星期六"]
                    bulan = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"]
                    hr = timeNow.strftime("%A")
                    bln = timeNow.strftime("%m")
                    for i in range(len(day)):
                        if hr == day[i]: hasil = hari[i]
                    for k in range(0, len(bulan)):
                        if bln == str(k): bln = bulan[k-1]
                    readTime = hasil + ", " + timeNow.strftime('%d') + " - " + bln + " - " + timeNow.strftime('%Y') + "\n時間 : [ " + timeNow.strftime('%H:%M:%S') + " ]"
                    cl.sendMessage(msg.to, readTime)
            elif msg.contentType == 7:
                if settings["checkSticker"] == True:
                    stk_id = msg.contentMetadata['STKID']
                    stk_ver = msg.contentMetadata['STKVER']
                    pkg_id = msg.contentMetadata['STKPKGID']
                    ret_ = "╔══[ Sticker Info ]"
                    ret_ += "\n╠ STICKER ID : {}".format(stk_id)
                    ret_ += "\n╠ STICKER PACKAGES ID : {}".format(pkg_id)
                    ret_ += "\n╠ STICKER VERSION : {}".format(stk_ver)
                    ret_ += "\n╠ STICKER URL : line://shop/detail/{}".format(pkg_id)
                    ret_ += "\n╚══[ Finish ]"
                    cl.sendMessage(to, str(ret_))
                if settings["copy"] == True:
                    _name = msg.contentMetadata["displayName"]
                    copy = msg.contentMetadata["mid"]
                    groups = cl.getGroup(msg.to)
                    targets = []
                    for s in groups.members:
                        if _name in s.displayName:
                            print ("[Target] Copy")
                            break                             
                        else:
                            targets.append(copy)
                    if targets == []:
                        cl.sendMessage(msg.to, "Not Found...")
                        pass
                    else:
                        for target in targets:
                            try:
                                cl.cloneContactProfile(target)
                                cl.sendMessage(msg.to, "Berhasil clone member tunggu beberapa")
                                settings['copy'] = False
                                break
                            except:
                                     msg.contentMetadata = {'mid': target}
                                     settings["copy"] = False
                                     break
        if op.type == 26:
            try:
                msg = op.message
                if settings["reread"] == True:
                    if msg.toType == 0:
                        cl.log("[%s]"%(msg._from)+msg.text)
                    else:
                        cl.log("[%s]"%(msg.to)+msg.text)
                    if msg.contentType == 0:
                        msg_dict[msg.id] = {"text":msg.text,"from":msg._from,"createdTime":msg.createdTime}
                else:
                    pass
            except Exception as e:
                print(e)
        if op.type == 65:
            try:
                at = op.param1
                msg_id = op.param2
                if settings["reread"] == True:
                    if msg_id in msg_dict:
                        if msg_dict[msg_id]["from"] not in bl:
                            cl.sendMessage(at,"%s\n[😁😁]\n%s"%(cl.getContact(msg_dict[msg_id]["from"]).displayName,msg_dict[msg_id]["text"]))
                            print ["收回訊息"]
                        del msg_dict[msg_id]
                else:
                    pass
            except Exception as e:
                print(e)
        if op.type == 26:
            msg = op.message
            text = msg.text
            msg_id = msg.id
            receiver = msg.to
            sender = msg._from
            if msg.toType == 0:
                if sender != cl.profile.mid:
                    to = sender
                else:
                    to = receiver
            else:
                to = receiver
                if settings["autoRead"] == True:
                    cl.sendChatChecked(to, msg_id)
                if to in read["readPoint"]:
                    if sender not in read["ROM"][to]:
                        read["ROM"][to][sender] = True
                if sender in settings["mimic"]["target"] and settings["mimic"]["status"] == True and settings["mimic"]["target"][sender] == True:
                   text = msg.text
                   if text is not None:
                       cl.sendMessage(msg.to,text)
                if msg.contentType == 0 and sender not in clMID and msg.toType == 2:
                    if 'MENTION' in msg.contentMetadata.keys()!= None:
                        names = re.findall(r'@(\w+)', text)
                        mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                        mentionees = mention['MENTIONEES']
                        lists = []
                        for mention in mentionees:
                            if clMID in mention["M"]:
                                if settings["detectMention"] == True:
                                    contact = cl.getContact(sender)
                                    cl.sendMessage(to, "แทคแล้วไม่แจกติกเดียวกือส่งแขกนะ😱😱😱")
                                    sendMessageWithMention(to, contact.mid)
                                break
        if op.type == 55:
            try:
                if op.param1 in read['readPoint']:
                    if op.param2 in read['readMember'][op.param1]:
                        pass
                    else:
                        read['readMember'][op.param1] += op.param2
                    read['ROM'][op.param1][op.param2] = op.param2
                    backupData()
                else:
                   pass
            except:
                pass
            try:
                if op.param1 in wait2['readPoint']:
                    Name = cl.getContact(op.param2).displayName
                    if Name in wait2['readMember'][op.param1]:
                        pass
                    else:
                        wait2['readMember'][op.param1] += "\n[•]" + Name
                        wait2['ROM'][op.param1][op.param2] = "[•]" + Name
                        print (time.time() + name)
                else:
                    pass
            except:
                pass
            try:
                if cctv['cyduk'][op.param1]==True:
                    if op.param1 in cctv['point']:
                        Name = cl.getContact(op.param2).displayName
                        if Name in cctv['sidermem'][op.param1]:
                            pass
                        else:
                            cctv['sidermem'][op.param1] += "\n~ " + Name
                            pref=['Hello']
                            print (time.time() + Name)
                    else:
                        pass
                else:
                    pass
            except:
                pass

    except Exception as error:
        logError(error)
def find_between_r( s, first, last ):
    try:
        start = s.rindex( first ) + len( first )
        end = s.rindex( last, start )
        return s[start:end]
    except ValueError:
        return ""
while True:
    try:
        ops = oepoll.singleTrace(count=50)
        if ops is not None:
            for op in ops:
                lineBot(op)
                oepoll.setRevision(op.revision)
    except Exception as e:
        logError(e)
